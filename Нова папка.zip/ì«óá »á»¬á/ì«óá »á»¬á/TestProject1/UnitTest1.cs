using Methods;
using NUnit.Framework.Internal;

namespace TestProject2
{
    public class Tests
    {
        private Dopulnitelno dopulnitelno1;
        [SetUp]

        public void Setup()
        {
            dopulnitelno1 = new();
        }

        [Test]
        public void TriangleNegativeSidesTest()
        {
            int a = -1;
            int b = -1;
            int c = -88;
            double result = dopulnitelno1.CalcTriangleArea(a, b, c);
            Assert.AreEqual(-1, result);
        }
        [Test]
        public void CalcTriangleAreaTest()
        {
            int a = 3;
            int b = 4;
            int c = 5;
            double result = dopulnitelno1.CalcTriangleArea(a, b, c);
            Assert.AreEqual(6, result);
        }
        [Test]
        public void NumberToDigitOutOfBoundsTest()
        {
            int num = -1;
            string result = dopulnitelno1.NumberToDigit(num);
            Assert.AreEqual("Invalid number!", result);
        }
        [Test]
        public void NumberToDigitTest()
        {
            int num = 0;
            string result = dopulnitelno1.NumberToDigit(num);
            Assert.AreEqual("zero", result);
        }
        [Test]
        public void EmptyArrayTest()
        {
            int[] tesstArr = { };
            Assert.AreEqual(-1, dopulnitelno1.FindMax(tesstArr));
        }
        [Test]
        public void FindMaxTest()
        {
            int[] tesstArr = { 1,8,6};
            double result = dopulnitelno1.FindMax(tesstArr);
            Assert.AreEqual(8, result);
        }
        [Test]
        public void InvalidInputPrintAsNumber()
        {
            double a = 19;
            string b = "k";
            Assert.AreEqual("error", dopulnitelno1.PrintAsNumber(a, b));
        }
        [Test]
        public void PrintAsNumberRoundTest()
        {
            double a = 19.9874;
            string b = "f";
            Assert.AreEqual("19,99", dopulnitelno1.PrintAsNumber(a, b));
        }
        [Test]
        public void PrintAsNumberPercentTest()
        {
            double a = 0.75;
            string b = "%";
            double result=0.75;
            Assert.AreEqual($"{result:P2}", dopulnitelno1.PrintAsNumber(a, b));
        }
        [Test]
        public void PrintAsNumberWithAddedSpacesTest()
        {
            double a = 2.30;
            string b = "r";
            string result = dopulnitelno1.PrintAsNumber(a, b);
            Assert.AreEqual("     2,3", result);
        }
        [Test]
        public void CalcDistanceInBounds()
        {
            double a = 3;
            double b = -1;
            double c = 3;
            double d = 2.5;
            bool horizontal, vertical;
            var result = dopulnitelno1.CalcDistance(a, b, c, d,out horizontal,out vertical);
            Assert.AreEqual(3.5, result);
        }
        [Test]
        public void CalcDistanceHorizontalTest()
        {
            double a = 3;
            double b = -1;
            double c = 3;
            double d = 2.5;
            bool horizontal, vertical;
            var result = dopulnitelno1.CalcDistance(a, b, c, d, out horizontal, out vertical);
            Assert.AreEqual(false, horizontal);
        }
        public void CalcDistanceVerticalTest()
        {
            double a = 3;
            double b = -1;
            double c = 3;
            double d = 2.5;
            bool horizontal, vertical;
            var result = dopulnitelno1.CalcDistance(a, b, c, d, out horizontal, out vertical);
            Assert.AreEqual(false, vertical);
        }
    }
}