using Methods;
namespace TestProject2
{
    public class Tests
    {
        private Dopulnitelno dopulnitelno1;
        [SetUp]

        public void Setup()
        {
            dopulnitelno1 = new();
        }

        [Test]
        public void TriangleNegativeSidesTest()
        {
            int a = -1;
            int b = -1;
            int c = -88;
            double result = dopulnitelno1.CalcTriangleArea(a, b, c);
            Assert.AreEqual(-1, result);
        }
        [Test]
        public void CalcTriangleAreaTest()
        {
            int a = 3;
            int b = 4;
            int c = 5;
            double result = dopulnitelno1.CalcTriangleArea(a, b, c);
            Assert.AreEqual(6, result);
        }
        [Test]
        public void NumberToDigitOutOfBoundsTest()
        {
            int num = -1;
            string result = dopulnitelno1.NumberToDigit(num);
            Assert.AreEqual("Invalid number!", result);
        }
        [Test]
        public void NumberToDigitTest()
        {
            int num = 0;
            string result = dopulnitelno1.NumberToDigit(num);
            Assert.AreEqual("zero", result);
        }
    }
}